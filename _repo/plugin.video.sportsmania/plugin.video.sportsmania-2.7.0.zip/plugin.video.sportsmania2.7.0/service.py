import urllib2,xbmc,xbmcaddon,os

PLUGIN='plugin.video.streamtvbox'
ADDON = xbmcaddon.Addon(id=PLUGIN)
datapath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
paki=os.path.join(datapath, "paki")
pak=os.path.join(datapath, "pak")
if os.path.exists(datapath) == False:
        os.makedirs(datapath)



try :
 DATA_URL='https://app.dynns.com/newpanel/output.php/playlist?type=xml&deviceSn=pakindiahd2'
 request = urllib2.Request(DATA_URL)
 base64string = 'bG9naW5hbHdheXM6QGRuQG44NDk='
 request.add_header("Authorization", "Basic %s" % base64string)   
 i1iIIII = urllib2.urlopen(request).read()
 I1 = open ( paki , mode = 'w' )
 I1 . write ( i1iIIII )
except : pass

